            <footer id="colophon" class="site-footer">

                <div class="page-container">

                    <div class="site-info">
                        <div class="page-container">
                            <div class="vc_row">
                                <div class="vc_col-md-12 wrap">
                                    <div class="left" style="line-height:30px">
                                        © 2019, Inner Beauty HK. All right reserved.
                                    </div>
                                    <div class="right">
                                    <img style="max-height:30px" src="<?php echo e(asset('assets/images/pay.png')); ?>" alt="" srcset="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- .site-info -->

            </footer>
<?php /**PATH D:\Projects\2019\laravel-inner\resources\views/components/footnote.blade.php ENDPATH**/ ?>