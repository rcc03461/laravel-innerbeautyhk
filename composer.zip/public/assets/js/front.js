let app = new Vue({
    data:{
        sideCart : false,
        products :[]
    },
    methods:{
        toggleCart(){
            this.sideCart = !this.sideCart;
        }
    },
    created(){
        console.log(1);

    }
});
app.$mount('#app');
